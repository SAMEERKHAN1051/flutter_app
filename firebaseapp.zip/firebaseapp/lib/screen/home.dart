import 'package:flutter/material.dart';
import 'package:firebaseapp/widgets/topTab.dart';

class MyHomeClass extends StatelessWidget {
  const MyHomeClass({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Toptab(), // This is your TabBar
          Expanded(
            // Wrap TabBarView inside an Expanded widget for proper layout
            child: DefaultTabController(
              length: 3,
              child: TabBarView(
                children: [
                  Center(child: Text('Tab 1')),
                  Center(child: Text('Tab 2')),
                  Center(child: Text('Tab 3')),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
