import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebaseapp/widgets/userlisttile.dart';
import 'package:flutter/material.dart';

class UserClass extends StatefulWidget {
  const UserClass({super.key});

  @override
  State<UserClass> createState() => _UserClassState();
}

class _UserClassState extends State<UserClass> {
  final db = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Users List"),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: db.collection("users").snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No users found'));
          }

          var data = snapshot.data!.docs;

          return ListView.builder(
            itemCount: data.length,
            itemBuilder: (context, index) {
              var userData = data[index].data() as Map<String, dynamic>;
              return Userlisttile(
                data: userData,
              );
            },
          );
        },
      ),
    );
  }
}
