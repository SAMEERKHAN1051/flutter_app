import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebaseapp/widgets/userListTile.dart';
import 'package:flutter/material.dart';

class UserClass extends StatefulWidget {
  const UserClass({super.key});

  @override
  State<UserClass> createState() => _UserClassState();
}

class _UserClassState extends State<UserClass> {
  final db = FirebaseFirestore.instance;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Expanded(
            child: StreamBuilder(
                stream: db.collection("users").snapshots(),
                builder: (context, snapshot) {
                  var data = snapshot.data!.docs;
                  return ListView.builder(
                      itemCount: data.length,
                      itemBuilder: (context, index) {
                        var userData = data[index].data();
                        return Userlisttile(
                          data: userData,
                        );
                      });
                })));
  }
}
