import 'package:flutter/material.dart';

class Userlisttile extends StatelessWidget {
  final Map<String, dynamic> data;

  const Userlisttile({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    return ListTile(
        // leading: CircleAvatar(child: Text(data['username'] ?? 'No Username')),
        trailing: Icon(Icons.more_horiz),
        title: Text(data['username'] ?? 'No Username'));
  }
}
