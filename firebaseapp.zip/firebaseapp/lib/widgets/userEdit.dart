import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebaseapp/screen/user.dart';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

class Useredit extends StatefulWidget {
  const Useredit({super.key, required this.id});

  final String id;

  @override
  State<Useredit> createState() => _UsereditState();
}

class _UsereditState extends State<Useredit> {
  var uuid = Uuid();
  final db = FirebaseFirestore.instance;
  final TextEditingController username = TextEditingController();
  final TextEditingController email = TextEditingController();
  final TextEditingController password = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  late DocumentSnapshot userDocument;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    try {
      var snapshot =
          await db.collection('users').where('id', isEqualTo: widget.id).get();
      if (snapshot.docs.isNotEmpty) {
        userDocument = snapshot.docs[0]; // Get the first document
        username.text = userDocument['username'];
        email.text = userDocument['email'];
        password.text = userDocument[
            'password']; // You might want to hash this before updating
        setState(() {});
      }
    } catch (e) {
      print("Error loading user data: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Edit User")),
      body: userDocument == null
          ? const Center(child: CircularProgressIndicator())
          : Center(
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 30.0, vertical: 20),
                child: SingleChildScrollView(
                  child: Form(
                    key: _formKey,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Username Field
                        TextFormField(
                          controller: username,
                          decoration: InputDecoration(
                            labelText: 'Enter your username',
                            prefixIcon:
                                Icon(Icons.person, color: Colors.purple),
                            filled: true,
                            fillColor: Colors.white,
                            contentPadding: EdgeInsets.symmetric(
                                vertical: 16, horizontal: 20),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide.none,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide:
                                  BorderSide(color: Colors.purple, width: 2),
                            ),
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Username is required';
                            }
                            return null;
                          },
                        ),
                        SizedBox(height: 16),

                        // Email Field
                        TextFormField(
                          controller: email,
                          decoration: InputDecoration(
                            labelText: 'Enter your Email',
                            prefixIcon: Icon(Icons.mail, color: Colors.purple),
                            filled: true,
                            fillColor: Colors.white,
                            contentPadding: EdgeInsets.symmetric(
                                vertical: 16, horizontal: 20),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide.none,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide:
                                  BorderSide(color: Colors.purple, width: 2),
                            ),
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Email is required';
                            }
                            if (!RegExp(r'\S+@\S+\.\S+').hasMatch(value)) {
                              return 'Please enter a valid email';
                            }
                            return null;
                          },
                        ),
                        SizedBox(height: 16),

                        // Password Field
                        TextFormField(
                          controller: password,
                          obscureText: true,
                          decoration: InputDecoration(
                            labelText: 'Enter your Password',
                            prefixIcon: Icon(Icons.lock, color: Colors.purple),
                            filled: true,
                            fillColor: Colors.white,
                            contentPadding: EdgeInsets.symmetric(
                                vertical: 16, horizontal: 20),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide.none,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide:
                                  BorderSide(color: Colors.purple, width: 2),
                            ),
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Password is required';
                            }
                            if (value.length < 6) {
                              return 'Password must be at least 6 characters';
                            }
                            return null;
                          },
                        ),
                        SizedBox(height: 24),

                        // Update Button
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            padding: EdgeInsets.symmetric(
                                vertical: 14, horizontal: 40),
                            foregroundColor: Colors.black,
                            backgroundColor: Colors.purple,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            textStyle: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          onPressed: () async {
                            if (_formKey.currentState?.validate() ?? false) {
                              final updatedUser = {
                                'username': username.text,
                                'email': email.text,
                                'password':
                                    password.text, // Make sure to hash this
                              };

                              try {
                                await db
                                    .collection('users')
                                    .doc(userDocument.id)
                                    .update(updatedUser);
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => const UserClass()),
                                );
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                      content: Text(
                                          'User data updated successfully!')),
                                );
                              } catch (e) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                      content: Text(
                                          'Failed to update user data: $e')),
                                );
                              }
                            }
                          },
                          child: Text('Update'),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
    );
  }
}
