import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebaseapp/widgets/userEdit.dart';
import 'package:flutter/material.dart';

class Userlisttile extends StatefulWidget {
  final Map<String, dynamic> data;

  Userlisttile({super.key, required this.data});

  final db = FirebaseFirestore.instance;

  // Function to delete data by id from Firestore
  void deleteDataById(String documentId) async {
    var snapshot =
        await db.collection('users').where('id', isEqualTo: documentId).get();
    print(snapshot);
    // If document(s) found, delete
    if (snapshot.docs.isNotEmpty) {
      for (var doc in snapshot.docs) {
        await doc.reference.delete(); // Delete the document
        print('User with id $documentId deleted');
      }
    } else {
      print('No user found with id: $documentId');
    }
  }

  @override
  State<Userlisttile> createState() => _UserlisttileState();
}

class _UserlisttileState extends State<Userlisttile> {
  @override
  Widget build(BuildContext context) {
    // Provide a default value for 'username' to avoid null errors
    final String username = widget.data['username'] ?? 'No Username';
    final String userEmail = widget.data['email'] ?? 'No Email';
    final String documentId =
        widget.data['id'] ?? "4546"; // Assuming 'id' is the document ID

    return ListTile(
      leading: CircleAvatar(
        backgroundColor: Colors.amber,
        child: Text(username[0]), // Take the first letter of the username
      ),
      subtitle: Text(userEmail),
      trailing: Row(
        mainAxisSize: MainAxisSize.min, // To prevent taking unnecessary space
        children: [
          IconButton(
            icon: Icon(Icons.delete),
            onPressed: () {
              widget.deleteDataById(documentId ?? "fdafdsa");
            },
          ),
          IconButton(
            icon: Icon(Icons.edit),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => Useredit(id: documentId)),
              );
            },
          ),
        ],
      ),
      title: Text(username), // Display the username
    );
  }
}
