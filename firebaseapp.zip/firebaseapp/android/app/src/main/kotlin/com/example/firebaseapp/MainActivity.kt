package com.example.firebaseapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
